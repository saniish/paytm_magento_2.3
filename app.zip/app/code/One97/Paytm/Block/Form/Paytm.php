<?php

namespace One97\Paytm\Block\Form;

class Paytm extends \Magento\Payment\Block\Form
{
    protected $_template = 'One97_Paytm::form/paytm.phtml';
}